#!/bin/sh

./configure --prefix=/usr/local/tmux LDFLAGS="-L/usr/local/libevent2/lib" CFLAGS="-I/usr/local/libevent2/include -I./compat/"
