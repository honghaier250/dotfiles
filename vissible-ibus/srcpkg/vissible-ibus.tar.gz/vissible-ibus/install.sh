cp vissible.db /usr/share/ibus-table/tables
cp vissible.gif /usr/share/ibus-table/icons
cp vissible.txt ~/
